const express = require('express')
const app = express();
const mongoose = require('mongoose')
const port = process.env.PORT || 3000
const NewStudent = require('./models/newStudent')
const rn = require('random-number');




const dbUrl = 'mongodb+srv://benuser:test1234@cluster0.cjdvpuq.mongodb.net/?retryWrites=true&w=majority';
mongoose.connect(dbUrl).then(() => {
    console.log('Connected to db');
    app.listen(port);
    
}).catch(err => console.log(err))



// setup view engine
app.set('view engine', 'ejs')

// middleware and static files
app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }));


// routes


app.get('/', (req, res) => {
    res.redirect('/loginFrm')
})



app.post('/checkerPage', (req, res) => {
    const newStudent = new NewStudent(req.body);
    const ranNumber = rn({min: 100000, max: 999999, integer: true});
    newStudent.idStudent = `c7${ranNumber}`;
    newStudent.save().then(result => {
        res.render('congraFrm', {userName: newStudent.userName})
    }).catch(err => {
        res.render('registerFrm', {checkVar: 'This user is already exist'})

    })
    
});


app.get('/loginFrm', (req, res) => {
    res.sendFile('./views/loginFrm.html', {root: __dirname})
})

app.get('/registerFrm', (req, res) => {
    res.render('registerFrm', {checkVar: ''});
    
})

app.get('/home', (req, res) => {
    res.render('home')
})

app.get('/courses', (req, res) => {
    res.render('courses')
})
